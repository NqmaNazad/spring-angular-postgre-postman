package com.methcook.methacademy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MethacademyApplicationTests {

	@Test
	void contextLoads() {
	}

}
