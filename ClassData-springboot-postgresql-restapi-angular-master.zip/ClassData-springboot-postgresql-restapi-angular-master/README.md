no### methacademy-springboot-postgressql-restapi-eternalsuffering

# Welcome to Meth Academy

## Connected Repo for Angular and Frontend. 
- Locate the Angular and Node setup in the 'sweaty.dev' folder.
- ## [Docs]([https://github.com/Hiratsuna/sweaty.exam/tree/main/docs](https://github.com/Hiratsuna/methacademy-springboot-postgressql-restapi-angular/tree/master/docs)) 
## - no idea what [this](https://github.com/Hiratsuna/methacademy.springboot_postgresql) is, lol xD
## - [Video Followed for Spring-Java-PostgreSQL-RestAPI Part](https://www.youtube.com/watch?v=eWbGV3LLwVQ)
## - [Video Followed for Angular -> Spring](https://www.youtube.com/watch?v=fv_EkS34afE)
# [POSTMAN REST API TESTS](https://methclass.postman.co/workspace/Team-Workspace~bf1a4036-c324-42a0-87ce-8eec1772e332/folder/28826781-1207dbdd-56a5-4684-9542-8033e1f5a8f9?ctx=documentation)

## Update from 30.07 
- Spring App (Java Server) finally ran successfully and was able to compile. 
- It is connected to PostgreSQL, success. <3 
- Now trying to get REST going as well and test it via Postman. 
- Will see if I can connect Angular with the VS Code project or I have to figure out how to place it inside the Spring project and run everything without falling apart. 
- Good Lucks to me! ~ 

## Update 2 from 30.07
- Added the docs folder on here 
- Will redo the Angular project and see what I can do at another time, because I have tried some stuff with chatgpt and ofcourse it ended up in horror, so will try a proper tutorial later when I restart my mind. xD I can not do anything this frustrated. I started disconnecting random ports from PC and to rage-uninstall things, so it's time to stop for now. :D

### So far what is done is:
- PostgreSQL database
- Connected to Java Spring Suite Application 
- Spring App Api Setup
- Working and tested with Postman (link of the test in docs, will add later, I am editing this on phone)
- 1/2 of Documentation

### What remains to be done:
- Angular frontend setup
- Connection established with Java backend
- Kubernetes helm chart 
- Remaining docs 

> If you wanna say something rude, keep in mind I have never done any of this before. 
- Also I am a Customer Support with no deggee or education in this field. 
> Keep it **CASUAL.**


# 2.08.2023 ANGULAR ATTACHED AND WORKING BRANCH ADDED TO REPO ! <3 
