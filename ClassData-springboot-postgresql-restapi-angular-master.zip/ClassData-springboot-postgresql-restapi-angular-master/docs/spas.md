Почваш да четеш тука как се билди АПИ
https://spring.io/guides/tutorials/rest/
Getting Started | Building REST services with Spring
Getting Started | Building REST services with Spring
Learn how to easily build RESTful services with Spring
Getting Started | Building REST services with Spring
После теглиш Postman
https://www.postman.com/
Postman
Postman API Platform | Sign Up for Free
Postman is an API platform for building and using APIs. Postman simplifies each step of the API lifecycle and streamlines collaboration so you can create better APIs—faster.
Postman API Platform | Sign Up for Free
С Postman тестваш всеки endpoint на тоя rest api който създадеш
https://www.redhat.com/en/topics/api/what-is-a-rest-api
What is a REST API?
A REST API (also known as RESTful API) is an application programming interface that conforms to the constraints of REST architecture. REST stands for representational state transfer.
