### list of what I need to end up with 

- kubernetes with a helm chart build setup and executed
- small angular app to monitor students in a particular course
- the front end needs to be its own entity and own front ent, so you need to use:
 - Java Service
 - Rest API 
 - Postgress Database 

 ## Progress question: What is a Kubernetes Cluster, What is a Helm Chart? What role does the helm chart play in current project and describe pls what are the benefits of using the Helm Chart and not something else. Are there any other suitable options with different benefits? Use this opportunity to compare them to the Helm Chart again and bring it back up in the topic, as we are using it now and I need to make sure I understand everything correctly. *Ask GPT* 

- Kubernetes can be a 'minicubes' and don't have to be a real cluster. 

 ## Ask chat:  - What is a minicube? How does it compare to the minicube? - What other similar service or real world example it can provide me?


